const search=document.querySelector(".search-box input")
let images=document.querySelector(".image-box");

search.addEventListener("keyup",e=>{
    if(e.key=="Enter"){
        let searchValue= search.value,
            value=searchValue.toLowerCase();
           /* console.log(searchValue)
            console.log(value)
            console.log(images)*/
            images = Array.from(images);
            images.forEach(image =>{
                if (value === image.dataset.name) {
                    return image.style.display ="block";
                    
                }
                image.style.display ="none";
            });    
            
            
    }
    
});

search.addEventListener("keyup",()=>{
    if(search.value!="") return;

    images.forEach(image=>{
        image.style.display='block';
    })
})
